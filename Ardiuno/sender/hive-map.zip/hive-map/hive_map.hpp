#ifndef HIVE_MAP_CPP_HIVE_MAP_HPP_
#define HIVE_MAP_CPP_HIVE_MAP_HPP_

#include "channel.h"
#include "destination.h"
#include "location.h"
#include "message.h"

#endif // HIVE_MAP_C_HIVE_MAP_H_
